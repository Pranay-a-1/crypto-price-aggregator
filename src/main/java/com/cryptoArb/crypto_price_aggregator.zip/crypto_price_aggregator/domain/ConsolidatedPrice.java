package com.cryptoArb.crypto_price_aggregator.domain;

import java.math.BigDecimal;
import java.time.Instant;

public record ConsolidatedPrice(
        CurrencyPair pair,
        BigDecimal bid,
        BigDecimal ask,
        Instant timestamp
) {
    public ConsolidatedPrice {
        if (pair == null) {
            throw new IllegalArgumentException("CurrencyPair cannot be null");
        }
        if (bid == null || bid.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Bid price must be non-negative");
        }
        if (ask == null || ask.compareTo(BigDecimal.ZERO) < 0) {
            throw new IllegalArgumentException("Ask price must be non-negative");
        }
        if (timestamp == null) {
            throw new IllegalArgumentException("Timestamp cannot be null");
        }
        // Valid business logic: Bid (what people pay) usually shouldn't be higher than Ask (what people sell for)
        // in a consolidated view, but in arbitrage, it might be.
        // For now, we strictly validate inputs, not market logic.
    }
}