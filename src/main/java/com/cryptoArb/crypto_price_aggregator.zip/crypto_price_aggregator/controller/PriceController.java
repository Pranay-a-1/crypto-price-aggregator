package com.cryptoArb.crypto_price_aggregator.controller;

import com.cryptoArb.crypto_price_aggregator.domain.ConsolidatedPrice;
import com.cryptoArb.crypto_price_aggregator.domain.CurrencyPair;
import com.cryptoArb.crypto_price_aggregator.service.PriceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.web.bind.annotation.*;

import java.util.Optional;

/**
 * REST controller for price endpoints.
 * 
 * Following SOLID principles:
 * - Single Responsibility: Only handles HTTP concerns, delegates to service
 * - Dependency Inversion: Depends on PriceService abstraction
 * 
 * Following RESTful design:
 * - GET /api/prices/{base}/{quote} - Fetch aggregated price
 * 
 * Error Handling:
 * - 200 OK: Price found
 * - 400 BAD REQUEST: Invalid input (empty base/quote)
 * - 404 NOT FOUND: Price not available
 * - 500 INTERNAL SERVER ERROR: Unexpected error
 */
@RestController
@RequestMapping("/api/prices")
public class PriceController {

    private static final Logger log = LoggerFactory.getLogger(PriceController.class);

    private final PriceService priceService;

    /**
     * Constructor with dependency injection.
     *
     * @param priceService The price service for fetching prices
     */
    public PriceController(PriceService priceService) {
        this.priceService = priceService;
    }

    /**
     * Get consolidated price for a currency pair.
     *
     * @param base  Base currency (e.g., BTC)
     * @param quote Quote currency (e.g., USD)
     * @return ResponseEntity with ConsolidatedPrice or error status
     */
    @GetMapping("/{base}/{quote}")
    public ResponseEntity<ConsolidatedPrice> getPrice(
            @PathVariable String base,
            @PathVariable String quote) {

        log.info("GET /api/prices/{}/{}", base, quote);

        try {
            // Validate input (fail-fast)
            if (base == null || base.isBlank()) {
                log.warn("Invalid request: base currency is empty");
                return ResponseEntity.badRequest().build();
            }
            if (quote == null || quote.isBlank()) {
                log.warn("Invalid request: quote currency is empty");
                return ResponseEntity.badRequest().build();
            }

            // Create currency pair (validation happens in constructor)
            CurrencyPair pair = new CurrencyPair(base, quote);

            // Fetch consolidated price
            Optional<ConsolidatedPrice> price = priceService.getConsolidatedPrice(pair);

            // Return 404 if not found, 200 if found
            return price
                    .map(p -> {
                        log.info("Price found for {}: bid={}, ask={}", pair, p.bid(), p.ask());
                        return ResponseEntity.ok(p);
                    })
                    .orElseGet(() -> {
                        log.warn("Price not found for {}", pair);
                        return ResponseEntity.notFound().build();
                    });

        } catch (IllegalArgumentException e) {
            // Invalid currency pair (e.g., empty base/quote)
            log.error("Invalid currency pair: {}", e.getMessage());
            return ResponseEntity.badRequest().build();

        } catch (Exception e) {
            // Unexpected error
            log.error("Unexpected error fetching price for {}/{}: {}",
                    base, quote, e.getMessage(), e);
            return ResponseEntity.status(HttpStatus.INTERNAL_SERVER_ERROR).build();
        }
    }
}
