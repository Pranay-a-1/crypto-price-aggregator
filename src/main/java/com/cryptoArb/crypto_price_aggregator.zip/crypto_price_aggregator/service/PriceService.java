package com.cryptoArb.crypto_price_aggregator.service;

import com.cryptoArb.crypto_price_aggregator.domain.ConsolidatedPrice;
import com.cryptoArb.crypto_price_aggregator.domain.CurrencyPair;

import java.util.Optional;

public interface PriceService {
    /**
     * Retrieves the latest consolidated price for a given currency pair.
     *
     * @param pair The currency pair to fetch (e.g., BTC/USD).
     * @return An Optional containing the price if found, or empty if not available.
     */
    Optional<ConsolidatedPrice> getConsolidatedPrice(CurrencyPair pair);
}