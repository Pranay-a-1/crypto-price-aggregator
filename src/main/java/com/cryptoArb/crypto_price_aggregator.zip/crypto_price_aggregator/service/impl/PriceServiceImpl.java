package com.cryptoArb.crypto_price_aggregator.service.impl;

import com.cryptoArb.crypto_price_aggregator.domain.ConsolidatedPrice;
import com.cryptoArb.crypto_price_aggregator.domain.CurrencyPair;
import com.cryptoArb.crypto_price_aggregator.domain.PriceTick;
import com.cryptoArb.crypto_price_aggregator.exception.PriceFetchException;
import com.cryptoArb.crypto_price_aggregator.service.PriceFetcher;
import com.cryptoArb.crypto_price_aggregator.service.PriceService;
import org.slf4j.Logger;
import org.slf4j.LoggerFactory;
import org.springframework.stereotype.Service;

import java.math.BigDecimal;
import java.time.Instant;
import java.util.ArrayList;
import java.util.List;
import java.util.Optional;

/**
 * Implementation of PriceService that aggregates prices from multiple fetchers.
 * 
 * Following SOLID principles:
 * - Single Responsibility: Only aggregates prices, doesn't fetch or expose
 * - Dependency Inversion: Depends on PriceFetcher abstraction via constructor
 * injection
 * - Open/Closed: New fetchers can be added without modifying this code
 * 
 * Aggregation Logic:
 * - Best Bid = MAX of all bids (highest price someone will pay)
 * - Best Ask = MIN of all asks (lowest price someone will sell)
 * 
 * Following KISS: Simple sequential fetching (Phase 2 will add concurrency)
 */
@Service
public class PriceServiceImpl implements PriceService {

    private static final Logger log = LoggerFactory.getLogger(PriceServiceImpl.class);

    private final List<PriceFetcher> fetchers;

    /**
     * Constructor with dependency injection.
     * Following Dependency Inversion Principle.
     *
     * @param fetchers List of price fetchers to aggregate from
     */
    public PriceServiceImpl(List<PriceFetcher> fetchers) {
        this.fetchers = fetchers != null ? fetchers : new ArrayList<>();
        log.info("PriceServiceImpl initialized with {} fetchers", this.fetchers.size());
    }

    @Override
    public Optional<ConsolidatedPrice> getConsolidatedPrice(CurrencyPair pair) {
        if (pair == null) {
            throw new IllegalArgumentException("CurrencyPair cannot be null");
        }

        log.debug("Fetching consolidated price for {}", pair);

        List<PriceTick> successfulTicks = new ArrayList<>();

        // Sequential fetching (KISS principle - Phase 2 will add concurrency)
        for (PriceFetcher fetcher : fetchers) {
            try {
                PriceTick tick = fetcher.fetchPrice(pair);
                successfulTicks.add(tick);
                log.debug("Fetched from {}: bid={}, ask={}",
                        fetcher.getExchange(), tick.bid(), tick.ask());
            } catch (PriceFetchException e) {
                // Gracefully skip failed fetchers (resilience)
                log.warn("Failed to fetch from {}: {}",
                        fetcher.getExchange(), e.getMessage());
            }
        }

        // If all fetchers failed, return empty
        if (successfulTicks.isEmpty()) {
            log.warn("No successful price fetches for {}", pair);
            return Optional.empty();
        }

        // Aggregate: Best bid (max), Best ask (min)
        ConsolidatedPrice consolidated = aggregateTicks(pair, successfulTicks);
        log.info("Consolidated price for {}: bid={}, ask={}",
                pair, consolidated.bid(), consolidated.ask());

        return Optional.of(consolidated);
    }

    /**
     * Aggregates multiple price ticks into a consolidated price.
     * Best bid = MAX (highest buy price)
     * Best ask = MIN (lowest sell price)
     */
    private ConsolidatedPrice aggregateTicks(CurrencyPair pair, List<PriceTick> ticks) {
        BigDecimal bestBid = ticks.stream()
                .map(PriceTick::bid)
                .max(BigDecimal::compareTo)
                .orElseThrow(() -> new IllegalStateException("No bids available"));

        BigDecimal bestAsk = ticks.stream()
                .map(PriceTick::ask)
                .min(BigDecimal::compareTo)
                .orElseThrow(() -> new IllegalStateException("No asks available"));

        return new ConsolidatedPrice(pair, bestBid, bestAsk, Instant.now());
    }
}
